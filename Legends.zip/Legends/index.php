
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Legends</title>
    <h1>Legends</h1>
    <hr>
  </head>
  <body>
<form action="insert.php" method="POST">
    <table>
  <tr>
    <td>
  First Name:
  </td>
    <td>
    <input type="text" Placeholder= "First Name" name="fname" required>
  </td>
    </tr>

    <tr>
      <td>
    Last Name:
    </td>
      <td>
      <input type="text" Placeholder= "Last Name" name="lname" required>
    </td>
      </tr>

      <tr>
        <td>
      Department :
      </td>
        <td>
        <input type="text" Placeholder= "Department" name="department" required>
      </td>
        </tr>

        <tr>
          <td>
        Job Position :
        </td>
          <td>
          <input type="text" Placeholder= "Job Position" name="jobPosition" required>
        </td>
          </tr>
          <tr>
            <td>
          Employee Number :
          </td>
            <td>
            <input type="text" Placeholder= "Employee Number " name="employeeNumber" required>
          </td>
            </tr>
    
  <tr>
    <td>
  Phone Number:
    </td>
    <td>
        <input type="Phone" Placeholder= "Phone Number" name="phoneNumber" required>
    </td>
  </tr>
      <tr>
        <td>
    Gender:
      </td>
        <td>
          <input type="radio" name="gender" value="m">Male
          <input type="radio" name="gender" value="f">Female
          <input type="radio" name="gender" value="o">Other
        </td>
        <tr>
      <td>
    Email:
    </td>
      <td>
      <input type="mail" Placeholder= "Email" name="email" required>
    </td>
      </tr>

        <tr>
      <td>
    Password:
    </td>
      <td>
      <input type="Password" Placeholder= "Password" name="password" required>
    </td>
      </tr>

<tr>
  <td>
<button type="submit" name="submit">Save</button>

</tr>
</td>
  </table>
</form>

</body>
</html>
