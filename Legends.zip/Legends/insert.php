<?php
$server="localhost";
$username="root";
$password="";
$dbname="legends";

$conn=mysqli_connect($server,$username,$password,$dbname);

if(isset($_POST['submit'])) {

if(!empty($_POST['fname']) && !empty($_POST['lname']) && !empty($_POST['department']) && !empty($_POST['jobPosition']) && !empty($_POST['employeeNumber']) && !empty($_POST['phoneNumber']) && !empty($_POST['gender']) && !empty($_POST['email']) && !empty($_POST['password']) ){

  
$fname=$_POST['fname'];
$lname=$_POST['lname'];
$department=$_POST['department'];
$jobPosition=$_POST['jobPosition'];
$employeeNumber=$_POST['employeeNumber'];
$phoneNumber=$_POST['phoneNumber'];
$gender=$_POST['gender'];
$email=$_POST['email'];
$password=$_POST['password'];


$query="INSERT INTO profile (fname,lname,department,jobPosition,employeeNumber,email,password,phoneNumber)
VALUES('$fname','$lname','$department','$jobPosition','$employeeNumber','$email','$password','$phoneNumber')";

$run=mysqli_query($conn,$query) or die(mysqli_error());
if($run){
  echo "Form submitted";
}
}
else{
  echo "all fields are required";
}
}

 ?>

